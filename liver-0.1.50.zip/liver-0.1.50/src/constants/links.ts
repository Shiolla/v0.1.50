export const GITHUB_REPO = 'https://github.com/zigamacele/liver'
export const HOLODEX_WEBSITE = 'https://holodex.net/'
