interface TwitterProps {
  width?: number
  height?: number
  className?: string
  fill?: string
}
const Twitter: React.FC<TwitterProps> = ({
  width = 12,
  height = 12,
  className,
  fill = '#555555',
}) => {
  return (
    <svg
      xmlns='http://www.w3.org/2000/svg'
      viewBox='64 64 896 896'
      focusable='false'
      data-icon='twitter-circle'
      fill='currentColor'
      aria-hidden='true'
      width={width}
      height={height}
      className={className}
    >
      <path
        d='M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm215.3 337.7c.3 4.7.3 9.6.3 14.4 0 146.8-111.8 315.9-316.1 315.9-63 0-121.4-18.3-170.6-49.8 9 1 17.6 1.4 26.8 1.4 52 0 99.8-17.6 137.9-47.4-48.8-1-89.8-33-103.8-77 17.1 2.5 32.5 2.5 50.1-2a111 111 0 01-88.9-109v-1.4c14.7 8.3 32 13.4 50.1 14.1a111.13 111.13 0 01-49.5-92.4c0-20.7 5.4-39.6 15.1-56a315.28 315.28 0 00229 116.1C492 353.1 548.4 292 616.2 292c32 0 60.8 13.4 81.1 35 25.1-4.7 49.1-14.1 70.5-26.7-8.3 25.7-25.7 47.4-48.8 61.1 22.4-2.4 44-8.6 64-17.3-15.1 22.2-34 41.9-55.7 57.6z'
        fill={fill}
      ></path>
    </svg>
  )
}

export default Twitter
