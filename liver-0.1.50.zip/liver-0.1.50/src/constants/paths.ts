export const HOME = '/'
export const SETTINGS = '/settings'
export const CUSTOM = '/custom'
export const ALL = '/all'
